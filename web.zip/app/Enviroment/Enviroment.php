<?php


namespace App\Enviroment;


class Enviroment{

    const CONTACT_TYPE = [
      "SALARY" => "Vay theo lương",
      "INSURANCE" => "Vay theo bảo hiểm nhân thọ",
      "CREDIT" => "Vay theo hạn mức thẻ tín dụng",
      "MONEY" => "Vay theo tiền măt",
    ];

    const CONTACT_LOCATION = [
        "HCM" => "TP. Hồ  Chí Minh",
        "BINHDUONG" => "Bình Dương",
        "DONGNAI" => "Đồng Nai",
        "LONGAN" => "Long An",
        "KHAC" => "Khu vực khác",
    ];
}
