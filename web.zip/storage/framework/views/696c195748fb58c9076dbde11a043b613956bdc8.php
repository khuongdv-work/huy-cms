<?php
    $type = \App\Enviroment\Enviroment::CONTACT_TYPE;
    $location = \App\Enviroment\Enviroment::CONTACT_LOCATION;
?>

<div class="widget-sidebar widget-form rounded">
    <h3 class="widget-title"><?php echo e($data->title); ?></h3>
    <div class="widget-content">
        <form name="form-contact" id="form-contact" method="post" action="<?php echo e(route('website.postContact')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" class="form-control" name="name" id="name" placeholder="Họ và tên">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="phone" id="phone" placeholder="Số điện thoại">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="passport" id="passport" placeholder="Chứng minh nhân dân">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="company" id="company" placeholder="Công ty hiện tại">
            </div>
            <div class="form-group">
                <select class="form-control" name="type">
                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <select class="form-control" name="location" id="location">
                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-100">Gửi</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/sidebar/formContact.blade.php ENDPATH**/ ?>