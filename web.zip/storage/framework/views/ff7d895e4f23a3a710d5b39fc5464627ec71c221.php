<?php $__env->startComponent('mail::message'); ?>
# Dear Mr. Huy,

Bạn vừa có người cần tư vấn với các thông tin như sau, vui lòng kiểm tra thông tin:
* Họ tên: <?php echo e($content['name']); ?>

* Số điện thoại: <?php echo e($content['phone']); ?>

* Công ty: <?php echo e($content['company']); ?>

* CMND: <?php echo e($content['passport']); ?>

* Loại vay: <?php echo e($content['type']); ?>

* Khu vực: <?php echo e($content['location']); ?>


<?php $__env->startComponent('mail::button', ['url' => $content['url']]); ?>
Tới trang quản lý
<?php echo $__env->renderComponent(); ?>

Thanks,<br />

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/emails/contact.blade.php ENDPATH**/ ?>