<div id="html-box">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title">
                    <h5><?php echo e($data->name); ?></h5>
                </div>
                <div class="html-text">
                    <?php echo $data->body; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/html.blade.php ENDPATH**/ ?>