<?php
    $sliders = \App\Slider::getSliders();
?>

<div id="slider">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
                <div class="slider-item">
                    <?php
                        $image = get_image_from_field($slider,'image');
                    ?>
                    <img src="<?php echo e(Voyager::image($image)); ?>" alt="">
                    <div class="slider-box" style="top: <?php echo e($slider->top); ?>%">
                        <?php echo $slider->name; ?>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Add Arrows -->
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
    </div>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/slider.blade.php ENDPATH**/ ?>