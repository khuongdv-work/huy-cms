<ul class="navbar-nav">
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $classes = $item->children->count() ? 'dropdown' : '' ?>
    <li class="nav-item <?= $classes ?>">
        <a target="<?php echo e($item->target); ?>" href="<?php echo e(url($item->url)); ?>" class="nav-link">
            <?php echo e($item->title); ?>

        </a>
        <?php if($item->children->count()): ?>
            <ul role="menu" class="dropdown-menu">
                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a target="<?php echo e($subItem->target); ?>" href="<?php echo e(url($subItem->url)); ?>"><?php echo e($subItem->title); ?></a></li>
                    <?php if(!$loop->last): ?> <li class="divider"></li> <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


















<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/common/menu.blade.php ENDPATH**/ ?>