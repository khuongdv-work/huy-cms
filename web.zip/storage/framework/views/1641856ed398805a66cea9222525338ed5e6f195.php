<div class="widget-sidebar widget-advisory rounded">
    <h3 class="widget-title"><?php echo e($data->title); ?></h3>
    <div class="widget-content">
       <?php echo $data->body; ?>

    </div>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/sidebar/html.blade.php ENDPATH**/ ?>