<div class="widget-google-map">
    <iframe id="gmap_canvas"
            src="https://maps.google.com/maps?q=37%20Ton%20duc%20thang&t=&z=13&ie=UTF8&iwloc=&output=embed"
            frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
    </iframe>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/gmap.blade.php ENDPATH**/ ?>