<?php
    $type = \App\Enviroment\Enviroment::CONTACT_TYPE;
    $location = \App\Enviroment\Enviroment::CONTACT_LOCATION;
?>

<!--FORM CONTACT -->
<div class="form-contact">
    <div class="top-contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="contact-title text-center">
                        <?php echo e($data->name); ?>

                    </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="content-contact">
        <div class="container">
            <form name="form-contact" id="form-contact" method="post" action="<?php echo e(route('website.postContact')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">
                        <p class="form-title">Đăng ký vay</p>
                        <p>Bạn vui lòng điền đầy đủ thông tin để chuyên viên tư vấn của chúng tôi có thể hỗ trợ bạn
                            tốt nhất, trong thời gian ngắn nhất sau khi nhận được liên hệ chúng tôi sẽ gọi điện xác
                            nhận với bạn</p>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" id="name" placeholder="Họ và tên">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="phone" id="phone"
                                   placeholder="Số điện thoại">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="passport" id="passport"
                                   placeholder="Chứng minh nhân dân">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="company" id="company"
                                   placeholder="Công ty hiện tại">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <select class="form-control" name="type">
                                <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="location" id="location">
                                <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Gửi ngay</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/khuongdv/Desktop/huy-cms/resources/views/website/widgets/formContact.blade.php ENDPATH**/ ?>