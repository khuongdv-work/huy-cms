<div class="widget-sidebar widget-advisory rounded">
    <h3 class="widget-title">{{ $data->title }}</h3>
    <div class="widget-content">
       {!! $data->body !!}
    </div>
</div>
