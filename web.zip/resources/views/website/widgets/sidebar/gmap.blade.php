<div class="widget-google rounded">
    <iframe width="100%" height="300"
            src="https://maps.google.com/maps?q=37%20Ton%20duc%20thang&t=&z=13&ie=UTF8&iwloc=&output=embed"
            frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
    </iframe>
</div>
