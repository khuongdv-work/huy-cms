<div id="html-box">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title">
                    <h5>{{ $data->name }}</h5>
                </div>
                <div class="html-text">
                    {!! $data->body !!}
                </div>
            </div>
        </div>
    </div>
</div>
