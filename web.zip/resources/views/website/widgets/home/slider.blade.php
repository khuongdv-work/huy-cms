<?php
    $sliders = \App\Slider::getSliders();
?>

<div id="slider">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            @foreach($sliders as $k => $slider)
            <div class="swiper-slide">
                <div class="slider-item">
                    <?php
                        $image = get_image_from_field($slider,'image');
                    ?>
                    <img src="{{ Voyager::image($image) }}" alt="">
                    <div class="slider-box" style="top: {{ $slider->top }}%">
                        {!! $slider->name !!}
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        <!-- Add Arrows -->
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
    </div>
</div>
